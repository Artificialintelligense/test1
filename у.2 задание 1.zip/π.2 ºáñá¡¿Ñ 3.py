mount = {12: 'December', 1: 'January', 2: 'February', 3: 'Mars', 4: ' April', 5: 'May', 6: 'Juny', 7: 'July', 8: 'August',
9: 'September', 10: 'Octomber', 11: 'November'}

period={12: 'Winter', 1: 'Winter', 2: 'Winter', 3: 'Spring', 4: ' Spring', 5: 'Spring', 6: 'Summer', 7: 'Summer', 8: 'Summer',
9: 'Autumn', 10: 'Autumn', 11: 'Autumn'}

n_mounts= int(input('enter mouth'))


print(period[n_mounts], mount[n_mounts])