my_list = [1, 2, 3, 587, True, {7: 7, 3: 78}, ("Python"), [5, 6, 34, 7, ]]
for i in my_list:
    print(type(i))
 