my_input_lust= input(' enter list with space:  ')
my_input_lust=my_input_lust.split()
for i in my_input_lust:
    print(i[0:10])